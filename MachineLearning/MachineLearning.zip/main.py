import os
import sys
import argparse
import subprocess
from pathlib import Path

# 📌 PATH BASE
BASE_PATH = Path(__file__).resolve().parent
sys.path.append(str(BASE_PATH))
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"

# 📁 CREAZIONE STRUTTURA
def ensure_directories():
    for folder in ["module", "module/model", "module/tasks", "module/data", "module/preprocessing", "models", "logs", "dataset", "ui", "scripts"]:
        path = BASE_PATH / folder
        path.mkdir(parents=True, exist_ok=True)
        init_file = path / "__init__.py"
        init_file.touch(exist_ok=True)

# 🧠 TRAINING
def train(task):
    from module.model.train_generic import GenericTrainer
    paths = {
        "code_generation": ("Salesforce/codet5-base", "dataset/dataset_migrated.json"),
        "text_classification": ("microsoft/codebert-base", "dataset/dataset_classification_v2.json"),
        "security_classification": ("microsoft/codebert-base", "dataset/dataset_security.json"),
    }
    model_name, dataset_path = paths[task]
    trainer = GenericTrainer(model_name, task, num_labels=5 if task == "security_classification" else 2)
    trainer.train(dataset_path, output_dir=f"models/{task}")

# 🧪 VALIDAZIONE DATASET
def validate():
    from module.scripts.validate_dataset import main as validate_main
    validate_main()

# 🖥️ STREAMLIT UI
def run_ui():
    subprocess.run(["streamlit", "run", str(BASE_PATH / "ui/app.py")])

# 💻 CLI PIPELINE INTERATTIVA
def run_pipeline():
    from module.tasks.task_pipeline import TaskPipeline
    model_paths = {
        "code_generation": "models/code_generation",
        "text_classification": "models/text_classification",
        "security_classification": "models/security_classification"
    }
    pipeline = TaskPipeline(model_paths)

    while True:
        text = input("✏️ Input (exit per uscire): ")
        if text.lower() == "exit":
            break
        task = pipeline.process("text_classification", text)
        print(f"Tipo: {task}")
        if task == "code":
            print(pipeline.process("code_explanation", text))
        else:
            print(pipeline.process("code_generation", text))

# 🎯 AVVIO
if __name__ == "__main__":

    ensure_directories()

    parser = argparse.ArgumentParser(description="Avvio generico progetto ML multi-task")
    parser.add_argument("--train", choices=["code_generation", "text_classification", "security_classification"])
    parser.add_argument("--validate", action="store_true")
    parser.add_argument("--ui", action="store_true")
    parser.add_argument("--pipeline", action="store_true")

    args = parser.parse_args()

    if args.train:
        train(args.train)
    elif args.validate:
        validate()
    elif args.ui:
        run_ui()
    elif args.pipeline:
        run_pipeline()
    else:
        parser.print_help()
