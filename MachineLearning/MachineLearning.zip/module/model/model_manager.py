# module/model/model_manager.py
from transformers import AutoModelForSeq2SeqLM, AutoModelForSequenceClassification, AutoTokenizer

class ModelManager:
    def __init__(self, model, tokenizer):
        self._model = model
        self._tokenizer = tokenizer

    def get_model(self):
        return self._model

    def get_tokenizer(self):
        return self._tokenizer
